#include <stdio.h>

int main(){
    int n, i;
    printf("digite um numero inteiro: ");
    scanf("%d", &n);
    for(i = 1; i <= n; i++){
        printf("%d ", i);
    }
}