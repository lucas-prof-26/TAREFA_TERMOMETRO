#include <stdio.h>

int main(){
    int n = 0, i, check = 0;
    printf("digite um numero inteiro para ver se e primo: ");
    scanf("%d", &n);

    for(i = 1; i <= n; i++){
        if(n % i == 0){
            check = check + 1;
        }
        if(check > 2){
            printf("%d nao e primo", n);
            break;
        } 
    }
    
    if(check == 2){
        printf("%d e primo!", n);
    }
}