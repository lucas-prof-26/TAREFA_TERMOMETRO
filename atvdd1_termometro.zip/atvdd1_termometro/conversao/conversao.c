#include <stdio.h>

int main(){
    char select;
    float f, c;
    printf("escolha entre f(Fahrenheit) e c(celsius): ");
    scanf("%c", &select);
    switch(select){
        case 'f':
            printf("digite o valor em Fahrenheit a ser convertido: ");
            scanf("%f", &f);
            c = ((f-32)*5)/9;
            printf("%.2fF = %.2fC", f, c);
            break;
        case 'c':
            printf("digite o valor em Celsius a ser convertido: ");
            scanf("%f", &c);
            f = ((c*9)/5)+32;
            printf("%.2fC = %.2fF", c, f);
            break;
        default:
            printf("valor invalido ou nao recebido");
            break;
    }
}