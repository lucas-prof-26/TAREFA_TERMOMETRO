#include <stdio.h>
#include <string.h>

int main(){
    char string[200];
    int i, n = 0;
    
    fgets(string, 200, stdin);

    while(i != '\n'){
        i = string[n];
        if(i != '\n'){
            n = n + 1;
        }
    }
    printf("quantidade de caracteres da string: %d ", n);
}