#include <stdio.h>

int main(){
    int n, i, res = 1;
    printf("digite um numero inteiro: ");
    scanf("%d", &n);
    for(i = n; i != 0; i--){
        res = i*res;
    }

    printf("%d! = %d", n, res);
}